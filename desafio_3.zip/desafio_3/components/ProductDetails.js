import React, { useState } from 'react';

const ProductDetails = ({ product, productId, onSave, onCancel }) => {
  const [editedProduct, setEditedProduct] = useState({ ...product });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedProduct({ ...editedProduct, [name]: value });
  };

  const handleSpecificationChange = (field, value) => {
    setEditedProduct({
      ...editedProduct,
      especificaciones: {
        ...editedProduct.especificaciones,
        [field]: value
      }
    });
  };

  const handleOptionChange = (optionType, value) => {
    setEditedProduct({
      ...editedProduct,
      opciones: {
        ...editedProduct.opciones,
        [optionType]: value
      }
    });
  };

  const handleImageChange = (index, value) => {
    const updatedImages = [...editedProduct.imagenes];
    updatedImages[index] = value;
    setEditedProduct({
      ...editedProduct,
      imagenes: updatedImages
    });
  };

  const handleSave = async () => {
    try {
      const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos/${productId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(editedProduct)
      });
      if (!response.ok) {
        throw new Error('Failed to update product');
      }
      onSave(editedProduct);
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };


  return (
    <div style={styles.detailContainer}>
      {/* Imágenes */}

      <h3>ID del producto: {productId}</h3> {/* Mostrar el ID del producto aquí */}
      <h3>Imágenes:</h3>
      <div>
        {editedProduct.imagenes.map((image, index) => (
          <div key={index} style={{ marginBottom: '10px' }}>
            <input
              type="text"
              name={`image-${index}`}
              value={image}
              onChange={(e) => handleImageChange(index, e.target.value)}
              placeholder={`URL de imagen ${index + 1}`}
              style={styles.input}
            />
          </div>
        ))}
      </div>

      {/* Nombre */}
      <input
        type="text"
        name="nombre"
        value={editedProduct.nombre}
        onChange={handleChange}
        placeholder="Nombre del producto"
        style={styles.input}
      />

      {/* Descripción */}
      <textarea
        name="descripcion"
        value={editedProduct.descripcion}
        onChange={handleChange}
        placeholder="Descripción del producto"
        style={styles.textarea}
      />

      {/* Precio */}
      <input
        type="number"
        name="precio"
        value={editedProduct.precio}
        onChange={handleChange}
        placeholder="Precio del producto"
        style={styles.input}
      />

      {/* Especificaciones */}
      <h3>Especificaciones:</h3>
      <div>
        {editedProduct.especificaciones && Object.entries(editedProduct.especificaciones).map(([key, value]) => (
  <input
    key={key}
    type="text"
    name={`especificaciones-${key}`}
    value={value || ''}
    onChange={(e) => handleSpecificationChange(key, e.target.value)}
    placeholder={key}
    style={styles.input}
  />
))}

      </div>

      {/* Opciones */}
      <h3>Opciones:</h3>
      <div>
       {editedProduct.opciones && Object.entries(editedProduct.opciones).map(([key, value]) => (
  <div key={key}>
    <label>{key}:</label>
    {Array.isArray(value) ? (
      <select
        name={`opciones-${key}`}
        value={value.join(',') || ''}
        onChange={(e) => handleOptionChange(key, e.target.value.split(','))}
        style={styles.input}
      >
        <option value="">Seleccionar {key}</option>
        {value.map((option, index) => (
          <option key={index} value={option}>{option}</option>
        ))}
      </select>
    ) : (
      <input
        type="text"
        name={`opciones-${key}`}
        value={value || ''}
        onChange={(e) => handleOptionChange(key, e.target.value)}
        placeholder={`Opciones ${key}`}
        style={styles.input}
      />
    )}
  </div>
))}

      </div>

      {/* Botones de guardar y cancelar */}
      <div style={styles.buttonContainer}>
        <button style={styles.saveButton} onClick={handleSave}>Guardar</button>
        <button style={styles.cancelButton} onClick={onCancel}>Cancelar</button>
      </div>
    </div>
  );
};

const styles = {
  detailContainer: {
    padding: '20px',
    borderBottom: '1px solid #ccc',
    backgroundColor: '#fff',
    borderRadius: '10px',
    marginVertical: '10px',
    boxShadow: '0px 2px 3px rgba(0, 0, 0, 0.25)',
  },
  input: {
    width: '100%',
    marginBottom: '10px',
    padding: '8px',
    fontSize: '16px',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  textarea: {
    width: '100%',
    height: '100px',
    marginBottom: '10px',
    padding: '8px',
    fontSize: '16px',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    padding: '10px 20px',
    cursor: 'pointer',
  },
  cancelButton: {
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    padding: '10px 20px',
    cursor: 'pointer',
  },
};

export default ProductDetails;
