import React, { useState, useEffect } from 'react';
import { View, FlatList } from 'react-native';
import Product from './Product';
import ProductDetails from './ProductDetails';
import SearchBar from './SearchBar';

const ProductList = ({ navigation, route }) => {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const { categoria } = route.params;

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos?categoria=${categoria}`);
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchProducts();
  }, [categoria]);

  const searchProducts = async (term) => {
    try {
      const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos?nombre=${term.toLowerCase()}`);
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error('Error searching products:', error);
    }
  };

  const showDetails = (product) => {
    setSelectedProduct(product);
  };

  const backToProducts = async () => {
    setSelectedProduct(null);
    const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos?categoria=${categoria}`);
    const data = await response.json();
    setProducts(data);
  };

  const renderProduct = ({ item }) => {
    if (!item) return null;
    return <Product product={item} onPress={() => showDetails(item)} />;
  };

  return (
    <View>
      <SearchBar onSearch={searchProducts} />
      {selectedProduct ? (
        <ProductDetails
          product={selectedProduct}
          productId={selectedProduct.id} // Pasar el ID del producto seleccionado
          onPressBack={backToProducts}
        />
      ) : (
        <FlatList
          data={products}
          renderItem={renderProduct}
          keyExtractor={(item) => item?.id?.toString()}
        />
      )}
    </View>
  );
};

export default ProductList;
