// Product.js
import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const Product = ({ product, onPress }) => {
  if (!product) {
    return null;
  }

  return (
    <TouchableOpacity onPress={onPress}>
      <View style={styles.productContainer}>
        <Image source={{ uri: product.foto }} style={styles.image} />
        <Text style={styles.name}>{product.nombre}</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  productContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    marginHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    paddingBottom: 10,
  },
  image: {
    width: 100,
    height: 100,
    marginRight: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default Product;
