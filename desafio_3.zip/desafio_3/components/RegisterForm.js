import React, { useState } from 'react';

const RegisterForm = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [profileImageUrl, setProfileImageUrl] = useState(''); // Para almacenar la URL de la imagen de perfil

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('https://660f73af356b87a55c5168c5.mockapi.io/desafio/Usuarios', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nombre_usuario: username,
          correo: email,
          contrasena: password,
          imagen_perfil: profileImageUrl, // Incluir la URL de la imagen de perfil en los datos enviados al servidor
        }),
      });

      const data = await response.json();
      console.log('Nuevo usuario registrado:', data);
      // Aquí puedes redirigir al usuario a la página de inicio de sesión o mostrar un mensaje de éxito, etc.
    } catch (error) {
      console.error('Error al registrar usuario:', error);
      // Aquí puedes manejar el error, por ejemplo, mostrando un mensaje al usuario
    }
  };

  return (
    <div>
      <h2>Registrarse</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Nombre de usuario:</label>
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
        </div>
        <div>
          <label>Correo electrónico:</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label>Contraseña:</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <div>
          <label>URL de la imagen de perfil:</label>
          <input type="text" value={profileImageUrl} onChange={(e) => setProfileImageUrl(e.target.value)} />
        </div>
        <button type="submit">Registrarse</button>
      </form>
    </div>
  );
};

export default RegisterForm;
